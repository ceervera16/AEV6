﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Proyecto.Clases {
    class Employee {
        private string id;
        private string name;
        private string firstName;
        private bool admin;
        private string password;

        public string Id { get { return id; } set { id = value; } }
        public string Name { get { return name; } set { name = value; } }
        public string FirstName { get { return firstName; } set { firstName = value; } }
        public bool Admin { get { return admin; } set { admin = value; } }
        public string Password { get { return password; } set { password = value; } }


        public Employee(string id, string name, string firstName, bool admin, string password) {
            this.id = id;
            this.name = name;
            this.firstName = firstName;
            this.admin = admin;
            this.password = password;
        }

        public int AddEmployee(MySqlConnection connection, Employee emp) {
            int retorno;
            string consulta = "INSERT INTO usuarios (id,name,firstName,admin,password) VALUES " +
                "(@id, @name, @firstName, @admin, @password)";

            // Trim: elimina espacios innecesarios en strings.
            MySqlCommand comando = new MySqlCommand(consulta, connection);
            comando.Parameters.AddWithValue("@id", emp.id);
            comando.Parameters.AddWithValue("@name", emp.Name.Trim());
            comando.Parameters.AddWithValue("@firstName", emp.FirstName.Trim());
            comando.Parameters.AddWithValue("@admin", emp.admin);
            comando.Parameters.AddWithValue("@password", emp.Password.Trim());

            retorno = comando.ExecuteNonQuery();

            return retorno;
        }
    }
}
