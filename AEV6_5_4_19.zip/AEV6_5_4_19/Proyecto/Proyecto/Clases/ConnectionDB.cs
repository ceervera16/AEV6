﻿using MySql.Data.MySqlClient;

namespace Proyecto.Clases {
    class ConnectionDB {
        // Atributo para gestionar la conexión.
        private MySqlConnection connection;

        // Propiedad para acceder a la conexión.
        public MySqlConnection Connection { get { return connection; } }

        // Constructor que instancia la conexión, definiendo la cadena de conexión (ConnectionString)

        public ConnectionDB() {
            string server = "server=db4free.net;";
            string oldguids = "oldguids=true;";
            string database = "database=evaluable6;";
            string user = "uid=jaumenset;";
            string password = "pwd=;";
            string connectionstring = server + oldguids + database + user + password;
        }

        // Método que se encarga de abrir la conexión
        // Devuelve true/false dependiendo si la conexión se ha abierto con éxito o no
        public bool OpenConnection() {
            try {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)  // Inicialmente no es necesario utilizar el objeto ex
            {
                return false;
            }
        }

        // Método que se encarga de cerrar la conexión (evitar dejar conexiones abiertas)
        // Devuelve true/false dependiendo si la conexión se ha cerrado con éxito
        public bool CloseConnection() {
            try {
                connection.Close();
                return true;
            }
            catch (MySqlException ex) // Inicialmente no es necesario utilizar el objeto ex
            {
                return false;
            }
        }
    }
}
